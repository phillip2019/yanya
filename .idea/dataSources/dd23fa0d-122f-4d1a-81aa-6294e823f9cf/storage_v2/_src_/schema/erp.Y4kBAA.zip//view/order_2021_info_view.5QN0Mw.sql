create definer = erp@`%` view order_2021_info_view as
select `ppb`.`product_id` AS `product_id`, sum(`ppb`.`qty`) AS `sale_qty`, sum(`pbi`.`amt`) AS `gmv`
from (`erp`.`pos_bill_index` `pbi`
         left join `erp`.`pos_product_bill` `ppb` on ((`ppb`.`pos_bill_id` = `pbi`.`id`)))
where ((1 = 1) and (`pbi`.`date_created` >= str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s')) and
       (`pbi`.`date_created` < str_to_date('2022-01-01', '%Y-%m-%d %H:%i:%s')))
group by `ppb`.`product_id`;

-- comment on column order_2021_info_view.product_id not supported: 如果商品已删除，可写入新商品id，原id保存到product0_id

