create definer = erp@`%` view product_level_view as
select `sku_full_tbl`.`level1`                   AS `level1`,
       count(distinct `sku_full_tbl`.`spu_code`) AS `spu_num`,
       sum(`sku_full_tbl`.`stock_amt`)           AS `stock_amt`,
       sum(`sku_full_tbl`.`stock_qty`)           AS `stock_qty`,
       sum(`sku_full_tbl`.`gmv_2021`)            AS `gmv_2021`,
       sum(`sku_full_tbl`.`sale_qty_2021`)       AS `sale_qty_2021`,
       sum(`sku_full_tbl`.`gmv_2022`)            AS `gmv_2022`,
       sum(`sku_full_tbl`.`sale_qty_2022`)       AS `sale_qty_2022`,
       sum(`sku_full_tbl`.`gmv_2022_1`)          AS `gmv_2022_1`,
       sum(`sku_full_tbl`.`sale_qty_2022_1`)     AS `sale_qty_2022_1`,
       sum(`sku_full_tbl`.`gmv_2022_2`)          AS `gmv_2022_2`,
       sum(`sku_full_tbl`.`sale_qty_2022_2`)     AS `sale_qty_2022_2`,
       sum(`sku_full_tbl`.`gmv_2022_3`)          AS `gmv_2022_3`,
       sum(`sku_full_tbl`.`sale_qty_2022_3`)     AS `sale_qty_2022_3`
from (select `sku_tbl`.`level1`                       AS `level1`,
             `sku_tbl`.`level2`                       AS `level2`,
             `sku_tbl`.`level3`                       AS `level3`,
             `sku_tbl`.`spu_name`                     AS `spu_name`,
             `sku_tbl`.`spu_code`                     AS `spu_code`,
             `sku_tbl`.`product_id`                   AS `product_id`,
             `sku_tbl`.`product_name`                 AS `product_name`,
             `sku_tbl`.`product_code`                 AS `product_code`,
             `sku_tbl`.`sale_price`                   AS `sale_price`,
             `sku_tbl`.`cost_price`                   AS `cost_price`,
             coalesce(`stock_tbl`.`stock_qty`, 0)     AS `stock_qty`,
             coalesce(`stock_tbl`.`amt`, 0)           AS `stock_amt`,
             coalesce(`order_2021_tbl`.`gmv`, 0)      AS `gmv_2021`,
             coalesce(`order_2021_tbl`.`sale_qty`, 0) AS `sale_qty_2021`,
             coalesce(`order_2022_tbl`.`gmv`, 0)      AS `gmv_2022`,
             coalesce(`order_2022_tbl`.`sale_qty`, 0) AS `sale_qty_2022`,
             coalesce(`order_01_tbl`.`gmv`, 0)        AS `gmv_2022_1`,
             coalesce(`order_01_tbl`.`sale_qty`, 0)   AS `sale_qty_2022_1`,
             coalesce(`order_02_tbl`.`gmv`, 0)        AS `gmv_2022_2`,
             coalesce(`order_02_tbl`.`sale_qty`, 0)   AS `sale_qty_2022_2`,
             coalesce(`order_03_tbl`.`gmv`, 0)        AS `gmv_2022_3`,
             coalesce(`order_03_tbl`.`sale_qty`, 0)   AS `sale_qty_2022_3`
      from (((((((select `pt1`.`p_name`                                           AS `level1`,
                         `pt1`.`p_code`                                           AS `level1_id`,
                         coalesce(`pt2`.`p_name`, `pt1`.`p_name`)                 AS `level2`,
                         coalesce(`pt2`.`p_code`, `pt1`.`p_code`)                 AS `level2_id`,
                         coalesce(`pt3`.`p_name`, `pt2`.`p_name`, `pt1`.`p_name`) AS `level3`,
                         coalesce(`pt3`.`p_code`, `pt2`.`p_code`, `pt1`.`p_code`) AS `level3_id`,
                         `t`.`id`                                                 AS `product_id`,
                         `t`.`spu_code`                                           AS `spu_code`,
                         `t`.`spu_name`                                           AS `spu_name`,
                         `t`.`code`                                               AS `product_code`,
                         `t`.`name`                                               AS `product_name`,
                         `pp`.`cost_price`                                        AS `cost_price`,
                         `pp`.`sale_price`                                        AS `sale_price`,
                         `t`.`created_at`                                         AS `created_at`,
                         date_format(`t`.`created_at`, '%Y-%m-%d')                AS `dt`,
                         `t`.`site_id`                                            AS `site_id`
                  from (((((select coalesce(`pt`.`p_code`, `source_t`.`code`) AS `spu_code`,
                                   `pt`.`p_name`                              AS `spu_name`,
                                   `source_t`.`id`                            AS `id`,
                                   `source_t`.`code`                          AS `code`,
                                   `source_t`.`name`                          AS `name`,
                                   `source_t`.`created_at`                    AS `created_at`,
                                   `source_t`.`site_id`                       AS `site_id`,
                                   substr(`source_t`.`p_paths`, 1, 4)         AS `p1_paths`,
                                   substr(`source_t`.`p_paths`, 1, 8)         AS `p2_paths`,
                                   substr(`source_t`.`p_paths`, 1, 12)        AS `p3_paths`,
                                   substr(`source_t`.`p_paths`, 1, 16)        AS `p4_paths`
                            from ((select `erp`.`product`.`id`                                                      AS `id`,
                                          `erp`.`product`.`code`                                                    AS `code`,
                                          `erp`.`product`.`name`                                                    AS `name`,
                                          `erp`.`product`.`create_date`                                             AS `created_at`,
                                          `erp`.`product`.`paths`                                                   AS `paths`,
                                          substr(`erp`.`product`.`paths`, 1,
                                                 (length(`erp`.`product`.`paths`) - 4))                             AS `p_paths`,
                                          `erp`.`product`.`site_id`                                                 AS `site_id`
                                   from `erp`.`product`
                                   where ((1 = 1) and (length(`erp`.`product`.`code`) in (12, 16, 18, 19)) and
                                          (`erp`.`product`.`has_child` = FALSE) and (`erp`.`product`.`create_date` >=
                                                                                     str_to_date('2022-02-28', '%Y-%m-%d %H:%i:%s'))))
                                  `source_t`
                                     left join (select `erp`.`product`.`code`  AS `p_code`,
                                                       `erp`.`product`.`name`  AS `p_name`,
                                                       `erp`.`product`.`paths` AS `p_paths`
                                                from `erp`.`product`
                                                where (`erp`.`product`.`has_child` = TRUE)) `pt`
                                               on ((`pt`.`p_paths` = `source_t`.`p_paths`)))
                            where (1 = 1)
                            union all
                            select `erp`.`product`.`code`                 AS `spu_code`,
                                   `erp`.`product`.`name`                 AS `spu_name`,
                                   `erp`.`product`.`id`                   AS `id`,
                                   `erp`.`product`.`code`                 AS `code`,
                                   `erp`.`product`.`name`                 AS `name`,
                                   `erp`.`product`.`create_date`          AS `created_at`,
                                   `erp`.`product`.`site_id`              AS `site_id`,
                                   substr(`erp`.`product`.`paths`, 1, 4)  AS `p1_paths`,
                                   substr(`erp`.`product`.`paths`, 1, 8)  AS `p2_paths`,
                                   substr(`erp`.`product`.`paths`, 1, 12) AS `p3_paths`,
                                   substr(`erp`.`product`.`paths`, 1, 16) AS `p4_paths`
                            from `erp`.`product`
                            where ((1 = 1) and (length(`erp`.`product`.`code`) not in (12, 16, 18, 19)) and
                                   (`erp`.`product`.`has_child` = FALSE) and
                                   (`erp`.`product`.`create_date` >= str_to_date('2022-02-28', '%Y-%m-%d %H:%i:%s')))
                            union all
                            select (case
                                        when (char_length(substring_index(`source_t2`.`name`, '/', 1)) < 4)
                                            then substring_index(substring_index(`source_t2`.`name`, '/', 2), '/', -(1))
                                        when (substr(`source_t2`.`name`, 1, 6) = '73144/')
                                            then substring_index(`source_t2`.`name`, '/', 2)
                                        when ((`source_t2`.`created_at` >=
                                               str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s')) and
                                              (char_length(substring_index(`source_t2`.`name`, '/', -(1))) < 5))
                                            then substring_index(substring_index(`source_t2`.`name`, '/', -(2)), '/', 1)
                                        when (`source_t2`.`created_at` >=
                                              str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s'))
                                            then substring_index(`source_t2`.`name`, '/', -(1))
                                        else substring_index(`source_t2`.`name`, '/', 1) end) AS `spu_code`,
                                   (case
                                        when (char_length(substring_index(`source_t2`.`name`, '/', 1)) < 4)
                                            then substring_index(substring_index(`source_t2`.`name`, '/', 2), '/', -(1))
                                        when (substr(`source_t2`.`name`, 1, 6) = '73144/')
                                            then substring_index(`source_t2`.`name`, '/', 2)
                                        when ((`source_t2`.`created_at` >=
                                               str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s')) and
                                              (char_length(substring_index(`source_t2`.`name`, '/', -(1))) < 5))
                                            then substring_index(substring_index(`source_t2`.`name`, '/', -(2)), '/', 1)
                                        when (`source_t2`.`created_at` >=
                                              str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s'))
                                            then substring_index(`source_t2`.`name`, '/', -(1))
                                        else substring_index(`source_t2`.`name`, '/', 1) end) AS `spu_name`,
                                   `source_t2`.`id`                                           AS `id`,
                                   `source_t2`.`code`                                         AS `code`,
                                   `source_t2`.`full_name`                                    AS `name`,
                                   `source_t2`.`created_at`                                   AS `created_at`,
                                   `source_t2`.`site_id`                                      AS `site_id`,
                                   substr(`source_t2`.`paths`, 1, 4)                          AS `p1_paths`,
                                   substr(`source_t2`.`paths`, 1, 8)                          AS `p2_paths`,
                                   substr(`source_t2`.`paths`, 1, 12)                         AS `p3_paths`,
                                   substr(`source_t2`.`paths`, 1, 16)                         AS `p4_paths`
                            from (select `erp`.`product`.`id`          AS `id`,
                                         `erp`.`product`.`code`        AS `code`,
                                         replace(replace(replace(`erp`.`product`.`name`, '3对装/', ''), '2对装/', ''),
                                                 '1对装/', '')           AS `name`,
                                         `erp`.`product`.`name`        AS `full_name`,
                                         `erp`.`product`.`create_date` AS `created_at`,
                                         `erp`.`product`.`site_id`     AS `site_id`,
                                         `erp`.`product`.`paths`       AS `paths`
                                  from `erp`.`product`
                                  where ((`erp`.`product`.`has_child` = FALSE) and (`erp`.`product`.`create_date` <
                                                                                    str_to_date('2022-02-28', '%Y-%m-%d %H:%i:%s')))) `source_t2`
                            where (1 = 1)) `t` left join (select `erp`.`product`.`code`  AS `p_code`,
                                                                 `erp`.`product`.`name`  AS `p_name`,
                                                                 `erp`.`product`.`paths` AS `p_paths`
                                                          from `erp`.`product`
                                                          where (`erp`.`product`.`has_child` = TRUE)) `pt3` on ((`pt3`.`p_paths` = `t`.`p3_paths`))) left join (select `erp`.`product`.`code`  AS `p_code`,
                                                                                                                                                                       `erp`.`product`.`name`  AS `p_name`,
                                                                                                                                                                       `erp`.`product`.`paths` AS `p_paths`
                                                                                                                                                                from `erp`.`product`
                                                                                                                                                                where (`erp`.`product`.`has_child` = TRUE)) `pt2` on ((`pt2`.`p_paths` = `t`.`p2_paths`))) left join (select `erp`.`product`.`code`  AS `p_code`,
                                                                                                                                                                                                                                                                             `erp`.`product`.`name`  AS `p_name`,
                                                                                                                                                                                                                                                                             `erp`.`product`.`paths` AS `p_paths`
                                                                                                                                                                                                                                                                      from `erp`.`product`
                                                                                                                                                                                                                                                                      where (`erp`.`product`.`has_child` = TRUE)) `pt1` on ((`pt1`.`p_paths` = `t`.`p1_paths`)))
                           left join (select `erp`.`product_price`.`product_id` AS `product_id`,
                                             `erp`.`product_price`.`site_id`    AS `site_id`,
                                             `erp`.`product_price`.`buy_price`  AS `cost_price`,
                                             `erp`.`product_price`.`price0`     AS `sale_price`
                                      from `erp`.`product_price`
                                      where (`erp`.`product_price`.`site_id` = 1251)) `pp`
                                     on (((`pp`.`product_id` = `t`.`id`) and (`pp`.`site_id` = `t`.`site_id`))))
                  where (1 = 1)) `sku_tbl` left join (select `erp`.`stock`.`product_id`              AS `product_id`,
                                                             `erp`.`stock`.`product_name`            AS `product_name`,
                                                             ((`erp`.`stock`.`qty` + `erp`.`stock`.`lock_qty`) +
                                                              coalesce(`erp`.`stock`.`move_qty`, 0)) AS `stock_qty`,
                                                             `erp`.`stock`.`amt`                     AS `amt`
                                                      from `erp`.`stock`
                                                      where ((1 = 1) and (`erp`.`stock`.`site_id` = 1251) and
                                                             (`erp`.`stock`.`qty` > 0) and
                                                             (`erp`.`stock`.`warehouse_code` not in
                                                              ('6052', '6061', '6078', '6079', '6080', '6082', '6087',
                                                               '6089', '6090', '6091', '6092', '6093', '6096', '6095',
                                                               '6094', '6097', '6098', '6099', '6100')))
                                                      group by `erp`.`stock`.`product_id`, `erp`.`stock`.`product_name`) `stock_tbl` on ((`stock_tbl`.`product_id` = `sku_tbl`.`product_id`))) left join (select `ppb`.`product_id` AS `product_id`,
                                                                                                                                                                                                                 sum(`ppb`.`qty`)   AS `sale_qty`,
                                                                                                                                                                                                                 sum(`pbi`.`amt`)   AS `gmv`
                                                                                                                                                                                                          from (`erp`.`pos_bill_index` `pbi`
                                                                                                                                                                                                                   left join `erp`.`pos_product_bill` `ppb`
                                                                                                                                                                                                                             on ((`ppb`.`pos_bill_id` = `pbi`.`id`)))
                                                                                                                                                                                                          where ((1 = 1) and
                                                                                                                                                                                                                 (`pbi`.`date_created` >= str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s')) and
                                                                                                                                                                                                                 (`pbi`.`date_created` < str_to_date('2022-01-01', '%Y-%m-%d %H:%i:%s')))
                                                                                                                                                                                                          group by `ppb`.`product_id`) `order_2021_tbl` on ((`order_2021_tbl`.`product_id` = `sku_tbl`.`product_id`))) left join (select `ppb`.`product_id` AS `product_id`,
                                                                                                                                                                                                                                                                                                                                         sum(`ppb`.`qty`)   AS `sale_qty`,
                                                                                                                                                                                                                                                                                                                                         sum(`pbi`.`amt`)   AS `gmv`
                                                                                                                                                                                                                                                                                                                                  from (`erp`.`pos_bill_index` `pbi`
                                                                                                                                                                                                                                                                                                                                           left join `erp`.`pos_product_bill` `ppb`
                                                                                                                                                                                                                                                                                                                                                     on ((`ppb`.`pos_bill_id` = `pbi`.`id`)))
                                                                                                                                                                                                                                                                                                                                  where ((1 = 1) and
                                                                                                                                                                                                                                                                                                                                         (`pbi`.`date_created` >= str_to_date('2022-01-01', '%Y-%m-%d %H:%i:%s')))
                                                                                                                                                                                                                                                                                                                                  group by `ppb`.`product_id`) `order_2022_tbl` on ((`order_2022_tbl`.`product_id` = `sku_tbl`.`product_id`))) left join (select `ppb`.`product_id` AS `product_id`,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                 sum(`ppb`.`qty`)   AS `sale_qty`,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                 sum(`pbi`.`amt`)   AS `gmv`
                                                                                                                                                                                                                                                                                                                                                                                                                                                          from (`erp`.`pos_bill_index` `pbi`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                   left join `erp`.`pos_product_bill` `ppb`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                             on ((`ppb`.`pos_bill_id` = `pbi`.`id`)))
                                                                                                                                                                                                                                                                                                                                                                                                                                                          where ((1 = 1) and
                                                                                                                                                                                                                                                                                                                                                                                                                                                                 (`pbi`.`date_created` >= str_to_date('2022-01-01', '%Y-%m-%d %H:%i:%s')) and
                                                                                                                                                                                                                                                                                                                                                                                                                                                                 (`pbi`.`date_created` < str_to_date('2022-02-01', '%Y-%m-%d %H:%i:%s')))
                                                                                                                                                                                                                                                                                                                                                                                                                                                          group by `ppb`.`product_id`) `order_01_tbl` on ((`order_01_tbl`.`product_id` = `sku_tbl`.`product_id`))) left join (select `ppb`.`product_id` AS `product_id`,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     sum(`ppb`.`qty`)   AS `sale_qty`,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     sum(`pbi`.`amt`)   AS `gmv`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              from (`erp`.`pos_bill_index` `pbi`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       left join `erp`.`pos_product_bill` `ppb`
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 on ((`ppb`.`pos_bill_id` = `pbi`.`id`)))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              where ((1 = 1) and
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     (`pbi`.`date_created` >= str_to_date('2022-02-01', '%Y-%m-%d %H:%i:%s')) and
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     (`pbi`.`date_created` < str_to_date('2022-03-01', '%Y-%m-%d %H:%i:%s')))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              group by `ppb`.`product_id`) `order_02_tbl` on ((`order_02_tbl`.`product_id` = `sku_tbl`.`product_id`)))
               left join (select `ppb`.`product_id` AS `product_id`,
                                 sum(`ppb`.`qty`)   AS `sale_qty`,
                                 sum(`pbi`.`amt`)   AS `gmv`
                          from (`erp`.`pos_bill_index` `pbi`
                                   left join `erp`.`pos_product_bill` `ppb` on ((`ppb`.`pos_bill_id` = `pbi`.`id`)))
                          where ((1 = 1) and
                                 (`pbi`.`date_created` >= str_to_date('2022-03-01', '%Y-%m-%d %H:%i:%s')) and
                                 (`pbi`.`date_created` < str_to_date('2022-04-01', '%Y-%m-%d %H:%i:%s')))
                          group by `ppb`.`product_id`) `order_03_tbl`
                         on ((`order_03_tbl`.`product_id` = `sku_tbl`.`product_id`)))
      where ((1 = 1) and (`sku_tbl`.`level1` not in ('淘汰', '淘汰类', '淘汰分类', '废弃', '废弃类', '淘汰款')) and
             (`sku_tbl`.`level2` not in ('淘汰', '淘汰类', '淘汰分类', '废弃', '废弃类', '淘汰款')) and
             (`sku_tbl`.`level3` not in ('淘汰', '淘汰类', '淘汰分类', '废弃', '废弃类', '淘汰款')) and
             (`sku_tbl`.`level1` not in ('批发辅材', '优惠券', '特价区', '淘汰')))) `sku_full_tbl`
where (1 = 1)
group by `sku_full_tbl`.`level1`
order by `gmv_2021` desc, `gmv_2022` desc;

