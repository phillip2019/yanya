create definer = erp@`%` view stock_info_view as
select `s`.`product_id`                                                  AS `product_id`,
       `s`.`product_name`                                                AS `product_name`,
       sum(((`s`.`qty` + `s`.`lock_qty`) + coalesce(`s`.`move_qty`, 0))) AS `stock_qty`,
       sum(round(coalesce((`pp`.`wholesale_price` * ((`s`.`qty` + `s`.`lock_qty`) + coalesce(`s`.`move_qty`, 0))),
                          `s`.`amt`), 2))                                AS `stock_amt`
from (`erp`.`stock` `s`
         left join (select `erp`.`product_price`.`product_id`     AS `product_id`,
                           max(`erp`.`product_price`.`buy_price`) AS `cost_price`,
                           max(`erp`.`product_price`.`price0`)    AS `sale_price`,
                           max(`erp`.`product_price`.`price1`)    AS `wholesale_price`
                    from `erp`.`product_price`
                    where (1 = 1)
                    group by `erp`.`product_price`.`product_id`) `pp` on ((`pp`.`product_id` = `s`.`product_id`)))
where ((1 = 1) and (`s`.`qty` > 0) and (`s`.`warehouse_code` not in
                                        ('6052', '6061', '6078', '6079', '6080', '6082', '6087', '6089', '6090', '6091',
                                         '6092', '6093', '6096', '6095', '6094', '6097', '6098', '6099', '6100')))
group by `s`.`product_id`, `s`.`product_name`;

