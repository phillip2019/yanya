create definer = erp@`%` view sku_info_view as
select `pt1`.`p_name`                                           AS `level1`,
       `pt1`.`p_code`                                           AS `level1_id`,
       coalesce(`pt2`.`p_name`, `pt1`.`p_name`)                 AS `level2`,
       coalesce(`pt2`.`p_code`, `pt1`.`p_code`)                 AS `level2_id`,
       coalesce(`pt3`.`p_name`, `pt2`.`p_name`, `pt1`.`p_name`) AS `level3`,
       coalesce(`pt3`.`p_code`, `pt2`.`p_code`, `pt1`.`p_code`) AS `level3_id`,
       `t`.`id`                                                 AS `product_id`,
       `t`.`spu_code`                                           AS `spu_code`,
       `t`.`spu_name`                                           AS `spu_name`,
       `t`.`code`                                               AS `product_code`,
       `t`.`name`                                               AS `product_name`,
       coalesce(`pp`.`cost_price`, 0)                           AS `cost_price`,
       coalesce(`pp`.`sale_price`, 0)                           AS `sale_price`,
       coalesce(`pp`.`wholesale_price`, 0)                      AS `wholesale_price`,
       `t`.`created_at`                                         AS `created_at`,
       date_format(`t`.`created_at`, '%Y-%m-%d')                AS `dt`,
       `t`.`site_id`                                            AS `site_id`
from (((((select coalesce(`pt`.`p_code`, `source_t`.`code`) AS `spu_code`,
                 `pt`.`p_name`                              AS `spu_name`,
                 `source_t`.`id`                            AS `id`,
                 `source_t`.`code`                          AS `code`,
                 `source_t`.`name`                          AS `name`,
                 `source_t`.`created_at`                    AS `created_at`,
                 `source_t`.`site_id`                       AS `site_id`,
                 substr(`source_t`.`p_paths`, 1, 4)         AS `p1_paths`,
                 substr(`source_t`.`p_paths`, 1, 8)         AS `p2_paths`,
                 substr(`source_t`.`p_paths`, 1, 12)        AS `p3_paths`,
                 substr(`source_t`.`p_paths`, 1, 16)        AS `p4_paths`
          from ((select `erp`.`product`.`id`                                                      AS `id`,
                        `erp`.`product`.`code`                                                    AS `code`,
                        `erp`.`product`.`name`                                                    AS `name`,
                        `erp`.`product`.`create_date`                                             AS `created_at`,
                        `erp`.`product`.`paths`                                                   AS `paths`,
                        substr(`erp`.`product`.`paths`, 1, (length(`erp`.`product`.`paths`) - 4)) AS `p_paths`,
                        `erp`.`product`.`site_id`                                                 AS `site_id`
                 from `erp`.`product`
                 where ((1 = 1) and (length(`erp`.`product`.`code`) in (12, 16, 18, 19)) and
                        (`erp`.`product`.`has_child` = FALSE) and
                        (`erp`.`product`.`create_date` >= str_to_date('2022-02-28', '%Y-%m-%d %H:%i:%s')))) `source_t`
                   left join (select `erp`.`product`.`code`  AS `p_code`,
                                     `erp`.`product`.`name`  AS `p_name`,
                                     `erp`.`product`.`paths` AS `p_paths`
                              from `erp`.`product`
                              where (`erp`.`product`.`has_child` = TRUE)) `pt`
                             on ((`pt`.`p_paths` = `source_t`.`p_paths`)))
          where (1 = 1)
          union all
          select `erp`.`product`.`code`                 AS `spu_code`,
                 `erp`.`product`.`name`                 AS `spu_name`,
                 `erp`.`product`.`id`                   AS `id`,
                 `erp`.`product`.`code`                 AS `code`,
                 `erp`.`product`.`name`                 AS `name`,
                 `erp`.`product`.`create_date`          AS `created_at`,
                 `erp`.`product`.`site_id`              AS `site_id`,
                 substr(`erp`.`product`.`paths`, 1, 4)  AS `p1_paths`,
                 substr(`erp`.`product`.`paths`, 1, 8)  AS `p2_paths`,
                 substr(`erp`.`product`.`paths`, 1, 12) AS `p3_paths`,
                 substr(`erp`.`product`.`paths`, 1, 16) AS `p4_paths`
          from `erp`.`product`
          where ((1 = 1) and (length(`erp`.`product`.`code`) not in (12, 16, 18, 19)) and
                 (`erp`.`product`.`has_child` = FALSE) and
                 (`erp`.`product`.`create_date` >= str_to_date('2022-02-28', '%Y-%m-%d %H:%i:%s')))
          union all
          select (case
                      when (char_length(substring_index(`source_t2`.`name`, '/', 1)) < 4) then substring_index(
                              substring_index(`source_t2`.`name`, '/', 2), '/', -(1))
                      when (substr(`source_t2`.`name`, 1, 6) = '73144/')
                          then substring_index(`source_t2`.`name`, '/', 2)
                      when ((`source_t2`.`created_at` >= str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s')) and
                            (char_length(substring_index(`source_t2`.`name`, '/', -(1))) < 5)) then substring_index(
                              substring_index(`source_t2`.`name`, '/', -(2)), '/', 1)
                      when (`source_t2`.`created_at` >= str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s'))
                          then substring_index(`source_t2`.`name`, '/', -(1))
                      else substring_index(`source_t2`.`name`, '/', 1) end) AS `spu_code`,
                 (case
                      when (char_length(substring_index(`source_t2`.`name`, '/', 1)) < 4) then substring_index(
                              substring_index(`source_t2`.`name`, '/', 2), '/', -(1))
                      when (substr(`source_t2`.`name`, 1, 6) = '73144/')
                          then substring_index(`source_t2`.`name`, '/', 2)
                      when ((`source_t2`.`created_at` >= str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s')) and
                            (char_length(substring_index(`source_t2`.`name`, '/', -(1))) < 5)) then substring_index(
                              substring_index(`source_t2`.`name`, '/', -(2)), '/', 1)
                      when (`source_t2`.`created_at` >= str_to_date('2021-01-01', '%Y-%m-%d %H:%i:%s'))
                          then substring_index(`source_t2`.`name`, '/', -(1))
                      else substring_index(`source_t2`.`name`, '/', 1) end) AS `spu_name`,
                 `source_t2`.`id`                                           AS `id`,
                 `source_t2`.`code`                                         AS `code`,
                 `source_t2`.`full_name`                                    AS `name`,
                 `source_t2`.`created_at`                                   AS `created_at`,
                 `source_t2`.`site_id`                                      AS `site_id`,
                 substr(`source_t2`.`paths`, 1, 4)                          AS `p1_paths`,
                 substr(`source_t2`.`paths`, 1, 8)                          AS `p2_paths`,
                 substr(`source_t2`.`paths`, 1, 12)                         AS `p3_paths`,
                 substr(`source_t2`.`paths`, 1, 16)                         AS `p4_paths`
          from (select `erp`.`product`.`id`                                                                  AS `id`,
                       `erp`.`product`.`code`                                                                AS `code`,
                       replace(replace(replace(`erp`.`product`.`name`, '3对装/', ''), '2对装/', ''), '1对装/', '') AS `name`,
                       `erp`.`product`.`name`                                                                AS `full_name`,
                       `erp`.`product`.`create_date`                                                         AS `created_at`,
                       `erp`.`product`.`site_id`                                                             AS `site_id`,
                       `erp`.`product`.`paths`                                                               AS `paths`
                from `erp`.`product`
                where ((`erp`.`product`.`has_child` = FALSE) and
                       (`erp`.`product`.`create_date` < str_to_date('2022-02-28', '%Y-%m-%d %H:%i:%s')))) `source_t2`
          where (1 = 1)) `t` left join (select `erp`.`product`.`code`  AS `p_code`,
                                               `erp`.`product`.`name`  AS `p_name`,
                                               `erp`.`product`.`paths` AS `p_paths`
                                        from `erp`.`product`
                                        where (`erp`.`product`.`has_child` = TRUE)) `pt3` on ((`pt3`.`p_paths` = `t`.`p3_paths`))) left join (select `erp`.`product`.`code`  AS `p_code`,
                                                                                                                                                     `erp`.`product`.`name`  AS `p_name`,
                                                                                                                                                     `erp`.`product`.`paths` AS `p_paths`
                                                                                                                                              from `erp`.`product`
                                                                                                                                              where (`erp`.`product`.`has_child` = TRUE)) `pt2` on ((`pt2`.`p_paths` = `t`.`p2_paths`))) left join (select `erp`.`product`.`code`  AS `p_code`,
                                                                                                                                                                                                                                                           `erp`.`product`.`name`  AS `p_name`,
                                                                                                                                                                                                                                                           `erp`.`product`.`paths` AS `p_paths`
                                                                                                                                                                                                                                                    from `erp`.`product`
                                                                                                                                                                                                                                                    where (`erp`.`product`.`has_child` = TRUE)) `pt1` on ((`pt1`.`p_paths` = `t`.`p1_paths`)))
         left join (select `erp`.`product_price`.`product_id` AS `product_id`,
                           `erp`.`product_price`.`site_id`    AS `site_id`,
                           `erp`.`product_price`.`buy_price`  AS `cost_price`,
                           `erp`.`product_price`.`price0`     AS `sale_price`,
                           `erp`.`product_price`.`price1`     AS `wholesale_price`
                    from `erp`.`product_price`
                    where (`erp`.`product_price`.`site_id` = 1251)) `pp`
                   on (((`pp`.`product_id` = `t`.`id`) and (`pp`.`site_id` = `t`.`site_id`))))
where (1 = 1);

